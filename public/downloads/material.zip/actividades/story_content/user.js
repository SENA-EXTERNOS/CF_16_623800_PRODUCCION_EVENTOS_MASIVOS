function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6fo5pDnMe5k":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

